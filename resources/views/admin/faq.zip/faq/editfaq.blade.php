@extends('layouts.adminHeader')
@section('sidebar')
    @extends('layouts.adminSidebar')
@endsection
@section('content')
    <div class="card card-warning">
        <div class="card-header">
            <h3 class="card-title float-left">Edit Faq</h3>
            <a href="{{ route('admin/faq') }}" class="btn btn-default float-right">Back</a>
        </div>

        <!-- /.card-header -->
        <div class="card-body">
            <form method="post" enctype="multipart/form-data" action="{{ route('admin/updatefaq') }}">
                @csrf
                <input type="hidden" id="faqid" name="id" value="{{ $data->id }}">
                <div class="row">
                    <div class="col-sm-12">
                        <label>Blog Name</label>
                        <select class="form-select" id="multiple-select-field" data-placeholder="Choose Blog Name" name="blog_id">
                            @foreach ($blog as $blogs)
                            <option value="{{ $blogs->id }}" {{ ($blogs->
                              id == $data->blog_id) ? 'selected':'' }}>{{
                              $blogs->title }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-sm-12 form-group">
                        <label>Title</label>
                        <input type="text" class="form-control" name="title" require placeholder="Enter Title"
                            value="{{ $data->title }}">
                        @if ($errors->has('title'))
                            <span class="text-danger">{{ $errors->first('title') }}</span>
                        @endif
                    </div>

                    <div class="col-sm-12 form-group">
                        <label>Description</label>
                        <textarea id="summernote" name="description" class="textarea"> {!! $data->description !!}</textarea>
                        @if ($errors->has('description'))
                            <span class="text-danger">{{ $errors->first('description') }}</span>
                        @endif
                    </div>
                </div>

         
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <button class="form-control btn btn-primary">Save</button>
                        </div>
                    </div>
                </div>

            </form> 
        </div>
        <!-- /.card-body -->
    </div>
@endsection

@section('footer')
    @include('layouts.adminFooter')
@endsection
